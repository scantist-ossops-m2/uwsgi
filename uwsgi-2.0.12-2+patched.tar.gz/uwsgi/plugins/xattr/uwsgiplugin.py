NAME='xattr'
CFLAGS=[]
LDFLAGS=[]
LIBS=[]
GCC_LIST = ['xattr']
