NAME='transformation_template'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['tt']
